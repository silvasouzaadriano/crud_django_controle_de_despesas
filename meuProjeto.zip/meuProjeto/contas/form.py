from django.forms import  ModelForm
from .models import Transacao, Categoria

class TransacaoForm(ModelForm):
    class Meta:
        model = Transacao
        fields = ['categoria','descricao','data','valor','observacoes']

class CategoriaForm(ModelForm):
    class Meta:
        model = Categoria
        fields = ['dt_criacao','nome']