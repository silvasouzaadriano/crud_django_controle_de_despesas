"""controle_gastos URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from contas.views import home, listagem_despesa, listagem_categoria, nova_transacao, update_transacao, delete_transacao, nova_categoria, update_categoria, delete_categoria

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', home, name='url_home'),
    path('listagem/', listagem_despesa, name='url_listagem'),
    path('listagem_categoria/', listagem_categoria, name='url_listagem_categoria'),
    path('nova/', nova_transacao, name='url_novo'),
    path('nova_categoria/', nova_categoria, name='url_nova_categoria'),
    path('update/<int:pk>/', update_transacao, name='url_update'),
    path('delete/<int:pk>/', delete_transacao, name='url_delete'),
    path('update_categoria/<int:pk>/', update_categoria, name='url_update_categoria'),
    path('delete_categoria/<int:pk>/', delete_categoria, name='url_delete_categoria'),
]
